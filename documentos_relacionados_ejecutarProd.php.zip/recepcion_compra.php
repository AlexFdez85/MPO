<?php
// recepcion_compra.php
require 'config.php';

session_start();
$userId = $_SESSION['user_id'];
$rol    = $_SESSION['rol'];

// 1) Procesar recepción (INSERT + stock + cerrar OC)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['oc_id'], $_POST['linea_id'])) {
    $oc = intval($_POST['oc_id']);

    // cargar mapa línea → {mp_id, ic_id, cantidad}
    $stmtLn = $pdo->prepare("
      SELECT id, mp_id, ic_id, cantidad
        FROM lineas_compra
       WHERE orden_compra_id = ?
    ");
    $stmtLn->execute([$oc]);
    $mapLn = [];
    foreach ($stmtLn->fetchAll(PDO::FETCH_ASSOC) as $ln) {
        $mapLn[$ln['id']] = $ln;
    }

    // preparar INSERT de recepción
    $ins = $pdo->prepare("
      INSERT INTO recepciones_compra_lineas
        (orden_compra_id, linea_id, lote, fecha_ingreso, factura_numero, recepcionador_id, comentario)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    foreach ($_POST['linea_id'] as $i => $lineaId) {
        $lote    = trim($_POST['lote'][$i])           ?: null;
        $fecha   = $_POST['fecha_ingreso'][$i]        ?: null;
        $factura = trim($_POST['factura_numero'][$i]) ?: null;
        $coment  = trim($_POST['comentario'][$i])     ?: null;
        if (!$lote && !$fecha && !$factura && !$coment) {
            continue;
        }
        $ins->execute([
            $oc,
            (int)$lineaId,
            $lote,
            $fecha,
            $factura,
            $userId,
            $coment
        ]);
        // actualizar stock
        if (!isset($mapLn[$lineaId])) {
            continue;
        }
        $ln = $mapLn[$lineaId];
        if ($ln['mp_id']) {
            $upd = $pdo->prepare("
              UPDATE materias_primas
                 SET existencia = existencia + ?
               WHERE id = ?
            ");
            $upd->execute([$ln['cantidad'], $ln['mp_id']]);
        } elseif ($ln['ic_id']) {
            $upd = $pdo->prepare("
              UPDATE insumos_comerciales
                 SET stock = stock + ?
               WHERE id = ?
            ");
            $upd->execute([$ln['cantidad'], $ln['ic_id']]);
        }
    }

    // cerrar la OC
    $pdo->prepare("UPDATE ordenes_compra SET estado='cerrada' WHERE id = ?")
        ->execute([$oc]);

    header('Location: recepcion_compra.php');
    exit;
}

// 2) Mostrar formulario de detalle si vienen con ?oc=###
if (isset($_GET['oc'])) {
    $ocId = intval($_GET['oc']);

    // cabecera OC pagada
    $hd = $pdo->prepare("
      SELECT oc.id, p.nombre AS proveedor, oc.fecha_emision,
             u.nombre AS solicitante
        FROM ordenes_compra oc
        JOIN proveedores p ON p.id = oc.proveedor_id
        JOIN usuarios    u ON u.id = oc.solicitante_id
       WHERE oc.id = ? AND oc.estado = 'pagada'
    ");
    $hd->execute([$ocId]);
    $oc = $hd->fetch(PDO::FETCH_ASSOC);
    if (!$oc) {
        header('Location: recepcion_compra.php');
        exit;
    }

    // líneas OC
    $ln = $pdo->prepare("
      SELECT lc.id AS linea_id,
             COALESCE(mp.nombre, ic.nombre) AS producto,
             lc.cantidad
        FROM lineas_compra lc
        LEFT JOIN materias_primas     mp ON mp.id = lc.mp_id
        LEFT JOIN insumos_comerciales ic ON ic.id = lc.ic_id
       WHERE lc.orden_compra_id = ?
    ");
    $ln->execute([$ocId]);
    $lines = $ln->fetchAll(PDO::FETCH_ASSOC);

    include 'header.php';
    ?>
    <div class="container mt-4">
      <h3 class="text-primary">Recepción OC #<?= $oc['id'] ?></h3>
      <p>
        <strong>Proveedor:</strong> <?= htmlspecialchars($oc['proveedor']) ?>
        &nbsp;|&nbsp;
        <strong>Solicita:</strong> <?= htmlspecialchars($oc['solicitante']) ?>
      </p>

      <form method="POST">
        <input type="hidden" name="oc_id" value="<?= $oc['id'] ?>">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Producto</th>
              <th class="text-end">Cantidad</th>
              <th>Lote</th>
              <th>Fecha Ingreso</th>
              <th>Factura #</th>
              <th>Comentario</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($lines as $r): ?>
            <tr>
              <td><?= htmlspecialchars($r['producto']) ?></td>
              <td class="text-end"><?= number_format($r['cantidad'],0,',','.') ?></td>
              <input type="hidden" name="linea_id[]" value="<?= $r['linea_id'] ?>">
              <td><input type="text"   name="lote[]"           class="form-control form-control-sm"></td>
              <td><input type="date"   name="fecha_ingreso[]"  class="form-control form-control-sm"></td>
              <td><input type="text"   name="factura_numero[]" class="form-control form-control-sm"></td>
              <td><input type="text"   name="comentario[]"     class="form-control form-control-sm" placeholder="(opcional)"></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <button class="btn btn-success">Guardar Recepción</button>
        <a href="recepcion_compra.php" class="btn btn-outline-secondary">Cancelar</a>
      </form>
    </div>
    <?php
    include 'footer.php';
    exit;
}

// 3) Listado de OCs pagadas pendientes de recibir
// Construyo el SELECT con la columna "responsable"
$baseSql = "
  SELECT
    oc.id            AS oc_id,
    p.nombre         AS proveedor,
    oc.fecha_emision,
    u.nombre         AS solicita,
    CASE
      WHEN EXISTS(
        SELECT 1 FROM lineas_compra lc
         WHERE lc.orden_compra_id = oc.id
           AND lc.mp_id IS NOT NULL
      ) THEN (
        SELECT nombre FROM usuarios WHERE rol = 'produccion' LIMIT 1
      )
      ELSE (
        SELECT nombre FROM usuarios WHERE rol = 'logistica' LIMIT 1
      )
    END AS responsable
  FROM ordenes_compra oc
  JOIN proveedores p ON p.id = oc.proveedor_id
  JOIN usuarios    u ON u.id = oc.solicitante_id
  WHERE oc.estado = 'pagada'
";

if (! in_array($rol, ['admin','gerente'], true)) {
    // el resto (p.ej logística) sólo ve sus propias OCs
    $baseSql .= " AND oc.solicitante_id = ?";
    $stmt = $pdo->prepare($baseSql . " ORDER BY oc.id DESC");
    $stmt->execute([$userId]);
} else {
    $stmt = $pdo->query($baseSql . " ORDER BY oc.id DESC");
}
$ocs = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'header.php';
?>
<div class="container mt-4">
  <h3 class="text-success">Recepción de Material</h3>

  <?php if (empty($ocs)): ?>
    <div class="alert alert-info">No hay órdenes pagadas pendientes de recibir.</div>
  <?php else: ?>
    <table class="table table-striped align-middle">
      <thead>
        <tr>
          <th># OC</th>
          <th>Proveedor</th>
          <th>Emisión</th>
          <th>Solicita</th>
          <th>Responsable</th>
          <th>Acción</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($ocs as $o): ?>
        <tr>
<td>
  <a href="autorizar_compra.php?view=historial&oc=<?= $o['oc_id'] ?>" class="text-decoration-none">
    <?= $o['oc_id'] ?>
  </a>
</td>
          <td><?= htmlspecialchars($o['proveedor']) ?></td>
          <td><?= $o['fecha_emision'] ?></td>
          <td><?= htmlspecialchars($o['solicita']) ?></td>
          <td><?= htmlspecialchars($o['responsable']) ?></td>
          <td>
            <a href="recepcion_compra.php?oc=<?= $o['oc_id'] ?>"
               class="btn btn-sm btn-success">Recibir Material</a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
<?php include 'footer.php'; ?>


