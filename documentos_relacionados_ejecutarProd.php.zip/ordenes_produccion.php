<?php
// ordenes_produccion.php

// -----------------------------
// 1. Mostrar errores (sólo desarrollo)
// -----------------------------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';

// -----------------------------
// 2. Validar sesión y rol
// -----------------------------
// Sólo usuarios con rol “admin”, “gerente” o “produccion” pueden acceder
if (!isset($_SESSION['user_id']) 
    || !in_array($_SESSION['rol'], ['admin','gerente','produccion'])) {
    header('Location: login.php');
    exit;
}

$usuario_id = $_SESSION['user_id'];
$nombre     = $_SESSION['nombre'];

// -----------------------------
// 3. Procesar creación de nueva orden
//    (cuando se envía el formulario “Generar Orden”)
// -----------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generar_orden'])) {
    // 3.1. Capturar datos del formulario
    $ficha_id = intval($_POST['ficha_id'] ?? 0);
    $cantidad = floatval($_POST['cantidad'] ?? 0);
    $fechaHoy = date('Y-m-d');

    // Validaciones básicas
    if ($ficha_id <= 0) {
        die("Error: Debes seleccionar una ficha de producción válida.");
    }
    if ($cantidad <= 0) {
        die("Error: La cantidad a producir debe ser mayor que cero.");
    }

    // 3.2. Obtener unidad (kg/g) directamente desde la ficha seleccionada
    $stmtUni = $pdo->prepare("
      SELECT unidad_produccion 
      FROM fichas_produccion 
      WHERE id = ?
    ");
    $stmtUni->execute([$ficha_id]);
    $rowUni = $stmtUni->fetch(PDO::FETCH_ASSOC);
    if (!$rowUni) {
        die("Error: Ficha de producción no encontrada.");
    }
    $unidadProduccion = $rowUni['unidad_produccion']; // 'kg' o 'g'

    // 3.3. Insertar la nueva orden en la tabla `ordenes_produccion`
    //      - cantidad_a_producir: será la cantidad enviada por el formulario
    //      - unidad: tomamos la unidad “kg” / “g” de la ficha
    //      - usuario_creador: grabamos el ID del usuario que generó la orden
    //      - estado_autorizacion: por defecto 'pendiente'
    //      - estado: por defecto 'pendiente'
    //      - fecha: fecha de hoy
    $insertOrden = $pdo->prepare("
      INSERT INTO ordenes_produccion
        (ficha_id, cantidad_a_producir, unidad, usuario_creador, estado_autorizacion, estado, fecha)
      VALUES (?, ?, ?, ?, 'pendiente', 'pendiente', ?)
    ");
    $insertOrden->execute([
      $ficha_id,
      $cantidad,
      $unidadProduccion,
      $usuario_id,
      $fechaHoy
    ]);

    // Redireccionar para evitar reenvío del formulario
    header("Location: ordenes_produccion.php?ok=1");
    exit;
}

// -----------------------------
// 4. Listar todas las “fichas de producción” para poblar el <select>
// -----------------------------
$fichas = $pdo->query("
  SELECT 
    fp.id                AS ficha_id,
    p.nombre             AS nombre_producto,
    fp.lote_minimo,
    fp.unidad_produccion
  FROM fichas_produccion fp
  JOIN productos p ON fp.producto_id = p.id
  ORDER BY p.nombre ASC
")->fetchAll(PDO::FETCH_ASSOC);

// -----------------------------
// 5. Traer todas las órdenes registradas (para mostrar en la tabla)
// -----------------------------
$ordenesAll = $pdo->query("
  SELECT 
    op.id                    AS orden_id,
    p.nombre                 AS producto,
    op.cantidad_a_producir   AS cantidad,
    op.unidad                AS unidad,
    op.estado                AS estado,
    op.estado_autorizacion   AS autorizacion,
    op.fecha_inicio          AS inicio,
    op.fecha                 AS fecha_creacion
  FROM ordenes_produccion op
  JOIN fichas_produccion fp ON op.ficha_id = fp.id
  JOIN productos p           ON fp.producto_id = p.id
  ORDER BY op.id DESC
")->fetchAll(PDO::FETCH_ASSOC);

?>

<?php include 'header.php'; ?>
<div class="container mt-4">
  <h3 class="text-danger mb-3">Órdenes de Producción</h3>

  <!-- Mensaje de éxito tras crear orden -->
  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success">
      La orden se generó correctamente.
    </div>
  <?php endif; ?>

  <!-- 6. Formulario para crear nueva orden -->
  <div class="card mb-4 p-3">
    <h5>Crear nueva orden</h5>
    <form method="POST">
      <div class="row g-3 align-items-end">
        <!-- 6.1 Select de Fichas -->
        <div class="col-md-6">
          <label>Producto / Ficha</label>
          <select name="ficha_id" class="form-select" required>
            <option value="">Selecciona ficha</option>
            <?php foreach ($fichas as $f): ?>
              <option value="<?= $f['ficha_id'] ?>">
                <?= htmlspecialchars($f['nombre_producto']) ?>
                 — Lote mínimo <?= number_format($f['lote_minimo'], 2) ?>
                 <?= htmlspecialchars($f['unidad_produccion']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- 6.2 Cantidad a producir -->
        <div class="col-md-4">
          <label>Cantidad a producir</label>
          <input 
            type="number" 
            step="0.01" 
            name="cantidad" 
            class="form-control" 
            placeholder="Ej. 25" 
            required
          >
        </div>

        <div class="col-md-2 text-end">
          <button type="submit" name="generar_orden" class="btn btn-primary px-4">
            Generar Orden
          </button>
        </div>
      </div>
    </form>
  </div>

  <!-- 7. Tabla con todas las órdenes registradas -->
  <h5>Órdenes registradas</h5>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Producto</th>
        <th>Cantidad</th>
        <th>Unidad</th>
        <th>Estado</th>
        <th>Autorización</th>
        <th>Inicio</th>
        <th>Fecha creación</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($ordenesAll as $ord): ?>
        <tr>
          <td>#<?= $ord['orden_id'] ?></td>
          <td><?= htmlspecialchars($ord['producto']) ?></td>
          <td><?= number_format($ord['cantidad'], 2) ?></td>
          <td><?= htmlspecialchars($ord['unidad']) ?></td>
          <td><?= ucfirst(htmlspecialchars($ord['estado'])) ?></td>
          <td><?= ucfirst(htmlspecialchars($ord['autorizacion'])) ?></td>
          <td>
            <?= $ord['inicio'] 
                ? date('Y-m-d', strtotime($ord['inicio'])) 
                : '—' ?>
          </td>
          <td>
            <?= $ord['fecha_creacion']
                ? date('Y-m-d', strtotime($ord['fecha_creacion'])) 
                : '—' ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include 'footer.php'; ?>

