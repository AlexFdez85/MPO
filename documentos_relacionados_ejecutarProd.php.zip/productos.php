<?php
// productos.php

// Mostrar errores en pantalla mientras se depura
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';

// Solo Admin o Gerente pueden acceder
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['rol'], ['admin', 'gerente'])) {
    header('Location: login.php');
    exit;
}

// 1) PROCESAR CREACIÓN o EDICIÓN de producto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_producto'])) {
    $nombre     = trim($_POST['nombre']);
    $densidad   = isset($_POST['densidad']) && $_POST['densidad'] !== '' 
                 ? floatval($_POST['densidad']) 
                 : null;
    $usuario_id = $_SESSION['user_id'];

    if (!empty($_POST['producto_id'])) {
        // --- EDICIÓN de un producto ya existente ---
        $pid = (int)$_POST['producto_id'];
        $stmt = $pdo->prepare("
          UPDATE productos 
            SET nombre = ?, densidad_kg_por_l = ? 
            WHERE id = ?
        ");
        $stmt->execute([$nombre, $densidad, $pid]);

        // Borrar presentaciones antiguas y luego reinsertar las nuevas
        $pdo->prepare("DELETE FROM productos_presentaciones WHERE producto_id = ?")
            ->execute([$pid]);

        $prodInsertId = $pid;
    } else {
        // --- CREACIÓN de producto nuevo ---
        $stmt = $pdo->prepare("
          INSERT INTO productos (nombre, densidad_kg_por_l, creado_por)
          VALUES (?, ?, ?)
        ");
        $stmt->execute([$nombre, $densidad, $usuario_id]);
        $prodInsertId = $pdo->lastInsertId();
    }

    // 2) ASOCIAR PRESENTACIONES seleccionadas
    if (!empty($_POST['presentaciones'])) {
        foreach ($_POST['presentaciones'] as $pres_id) {
            $stmt2 = $pdo->prepare("
              INSERT INTO productos_presentaciones 
                (producto_id, presentacion_id) VALUES (?, ?)
            ");
            $stmt2->execute([$prodInsertId, (int)$pres_id]);
        }
    }

    header("Location: productos.php?ok=1");
    exit;
}

// 3) PROCESAR BORRAR producto (con sus presentaciones)
if (isset($_GET['borrar']) && is_numeric($_GET['borrar'])) {
    $pid = (int)$_GET['borrar'];
    // Primero eliminamos de la tabla pivot
    $pdo->prepare("DELETE FROM productos_presentaciones WHERE producto_id = ?")
        ->execute([$pid]);
    // Luego eliminamos el producto
    $pdo->prepare("DELETE FROM productos WHERE id = ?")
        ->execute([$pid]);

    header("Location: productos.php?ok_borrar=1");
    exit;
}

// 4) Si vienen para editar, cargamos los datos existentes
$editar = false;
if (isset($_GET['editar']) && is_numeric($_GET['editar'])) {
    $editar = true;
    $prod_id = (int)$_GET['editar'];
    // Obtenemos datos del producto
    $stmt = $pdo->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt->execute([$prod_id]);
    $productoEdit = $stmt->fetch(PDO::FETCH_ASSOC);

    // Obtenemos presentaciones asociadas
    $stmt2 = $pdo->prepare("
      SELECT presentacion_id 
      FROM productos_presentaciones 
      WHERE producto_id = ?
    ");
    $stmt2->execute([$prod_id]);
    $presentacionesSelect = array_column($stmt2->fetchAll(PDO::FETCH_ASSOC), 'presentacion_id');
}

// 5) Listar todos los productos (para mostrar en tabla), incluyendo densidad
$productosAll = $pdo->query("
  SELECT 
    p.id, 
    p.nombre, 
    p.densidad_kg_por_l, 
    u.nombre AS quien_creo
  FROM productos p
  JOIN usuarios u ON p.creado_por = u.id
  ORDER BY p.nombre ASC
")->fetchAll(PDO::FETCH_ASSOC);

// 6) Listar todas las presentaciones disponibles
$presentacionesAll = $pdo->query("
  SELECT id, nombre 
  FROM presentaciones 
  ORDER BY nombre ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include 'header.php'; ?>
<div class="container mt-4">
  <h3 class="text-danger mb-3">Catálogo de Productos</h3>

  <!-- Mensajes de éxito -->
  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success">Se guardó el producto correctamente.</div>
  <?php endif; ?>
  <?php if (isset($_GET['ok_borrar'])): ?>
    <div class="alert alert-success">Producto eliminado correctamente.</div>
  <?php endif; ?>

  <!-- 1. Formulario para crear/editar producto -->
  <div class="card mb-4 p-3">
    <h5><?= $editar ? "Editar Producto" : "Nuevo Producto" ?></h5>
    <form method="POST">
      <?php if ($editar): ?>
        <input type="hidden" name="producto_id" value="<?= $productoEdit['id'] ?>">
      <?php endif; ?>

      <div class="row mb-2">
        <div class="col-md-6">
          <label>Nombre del producto</label>
          <input 
            type="text" 
            name="nombre" 
            class="form-control" 
            value="<?= $editar ? htmlspecialchars($productoEdit['nombre']) : "" ?>" 
            required
          >
        </div>
        <div class="col-md-3">
          <label>Densidad (kg/L) <small class="text-muted">(opcional)</small></label>
          <input 
            type="number" 
            step="0.0001" 
            name="densidad" 
            class="form-control" 
            value="<?= $editar && $productoEdit['densidad_kg_por_l'] !== null 
                      ? htmlspecialchars($productoEdit['densidad_kg_por_l']) 
                      : "" 
                   ?>"
            placeholder="0.9000"
          >
        </div>
      </div>

      <label>Presentaciones disponibles</label>
      <div class="row mb-3">
        <?php foreach ($presentacionesAll as $pr): ?>
          <div class="form-check col-md-2">
            <input 
              type="checkbox" 
              class="form-check-input" 
              name="presentaciones[]" 
              id="pres_<?= $pr['id'] ?>" 
              value="<?= $pr['id'] ?>"
              <?= $editar && in_array($pr['id'], $presentacionesSelect ?? []) 
                  ? "checked" 
                  : "" 
              ?>
            >
            <label class="form-check-label" for="pres_<?= $pr['id'] ?>">
              <?= htmlspecialchars($pr['nombre']) ?>
            </label>
          </div>
        <?php endforeach; ?>
      </div>

      <button name="guardar_producto" class="btn btn-primary">
        <?= $editar ? "Actualizar Producto" : "Crear Producto" ?>
      </button>
      <?php if ($editar): ?>
        <a href="productos.php" class="btn btn-secondary ms-2">Cancelar</a>
      <?php endif; ?>
    </form>
  </div>

  <!-- 2. Tabla con los productos ya creados -->
  <h5>Listado de productos</h5>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Producto</th>
        <th>Densidad (kg/L)</th>
        <th>Creado por</th>
        <th>Presentaciones</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($productosAll as $prod):
          // Obtener presentaciones asociadas para mostrar en texto
          $stmt3 = $pdo->prepare("
            SELECT pr.nombre 
            FROM presentaciones pr
            JOIN productos_presentaciones pp ON pr.id = pp.presentacion_id
            WHERE pp.producto_id = ?
          ");
          $stmt3->execute([$prod['id']]);
          $presList = array_column($stmt3->fetchAll(PDO::FETCH_ASSOC), 'nombre');
      ?>
        <tr>
          <td><?= htmlspecialchars($prod['nombre']) ?></td>
          <td>
            <?= $prod['densidad_kg_por_l'] !== null 
                ? htmlspecialchars($prod['densidad_kg_por_l']) 
                : "—" ?>
          </td>
          <td><?= htmlspecialchars($prod['quien_creo']) ?></td>
          <td><?= !empty($presList) ? implode(", ", $presList) : "—" ?></td>
          <td>
            <a href="productos.php?editar=<?= $prod['id'] ?>" class="btn btn-sm btn-secondary">Editar</a>
            <a 
              href="productos.php?borrar=<?= $prod['id'] ?>" 
              onclick="return confirm('¿Seguro que quieres eliminar este producto?')"
              class="btn btn-sm btn-danger ms-1"
            >Eliminar</a>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include 'footer.php'; ?>
