<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['rol'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Autorizar o rechazar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['orden_id'];
    $accion = $_POST['accion']; // 'autorizar' o 'rechazar'

    $nuevo_estado = ($accion === 'autorizar') ? 'autorizada' : 'rechazada';
    $stmt = $pdo->prepare("UPDATE ordenes_produccion SET estado_autorizacion = ?, autorizado_por = ? WHERE id = ?");
    $stmt->execute([$nuevo_estado, $_SESSION['user_id'], $id]);

    header("Location: autorizar_produccion.php");
    exit;
}

// Cargar órdenes pendientes
$ordenes = $pdo->query("
    SELECT op.id, p.nombre AS producto, op.cantidad_a_producir, f.unidad_produccion, u.nombre AS solicitante, op.fecha
    FROM ordenes_produccion op
    JOIN fichas_produccion f ON op.ficha_id = f.id
    JOIN productos p ON f.producto_id = p.id
    JOIN usuarios u ON op.usuario_creador = u.id
    WHERE op.estado_autorizacion = 'pendiente'
    ORDER BY op.fecha DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include 'header.php'; ?>
<div class="container mt-5">
  <h3 class="text-danger mb-4">Autorizar Órdenes de Producción</h3>

  <?php if (count($ordenes) === 0): ?>
    <div class="alert alert-info">No hay órdenes pendientes de autorización.</div>
  <?php else: ?>
    <table class="table table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Producto</th>
          <th>Cantidad</th>
          <th>Unidad</th>
          <th>Solicitado por</th>
          <th>Fecha</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($ordenes as $o): ?>
          <tr>
            <td>#<?= $o['id'] ?></td>
            <td><?= $o['producto'] ?></td>
            <td><?= $o['cantidad_a_producir'] ?></td>
            <td><?= $o['unidad_produccion'] ?></td>
            <td><?= $o['solicitante'] ?></td>
            <td><?= $o['fecha'] ?? '—' ?></td>
            <td>
              <form method="POST" class="d-inline">
                <input type="hidden" name="orden_id" value="<?= $o['id'] ?>">
                <button name="accion" value="autorizar" class="btn btn-success btn-sm">Autorizar</button>
                <button name="accion" value="rechazar" class="btn btn-danger btn-sm ms-1">Rechazar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
<?php include 'footer.php'; ?>
