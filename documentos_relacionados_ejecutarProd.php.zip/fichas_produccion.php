<?php
require_once 'config.php';

// Solo Admin puede entrar a esta página
if (!isset($_SESSION['user_id']) || $_SESSION['rol'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// 1) PROCESAR GUARDADO DE LA FICHA
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1.1. Capturar el nombre libre del producto a fabricar
    $nombre_producto = trim($_POST['nombre_producto']);
    $usuario_id      = $_SESSION['user_id'];

    if ($nombre_producto === '') {
        die("Error: Debes indicar un nombre para el producto a fabricar.");
    }

    // 1.2. Comprobar si ya existe el producto en la tabla `productos`
    $stmt0 = $pdo->prepare("SELECT id FROM productos WHERE nombre = ?");
    $stmt0->execute([$nombre_producto]);
    $filaProd = $stmt0->fetch(PDO::FETCH_ASSOC);

    // 1.2.1. ¿Es “de venta”?
    $esParaVenta   = isset($_POST['para_venta']) ? 1 : 0;        // 1 = producto de venta
    // ←– NUEVO: ¿Es subproceso?
    $esSubproceso  = isset($_POST['es_subproducto']) ? 1 : 0;     // 1 = producto subproceso

    if ($filaProd) {
        // El producto ya existía: obtenemos su ID y actualizamos banderas
        $producto_id = $filaProd['id'];

        // Si la casilla “Para Venta” está marcada, forzamos es_para_venta = 1
        if ($esParaVenta) {
            $pdo->prepare("UPDATE productos SET es_para_venta = 1 WHERE id = ?")
                ->execute([$producto_id]);
        }
        // ←– Si la casilla “Es Subproceso” está marcada, forzamos es_subproducto = 1
        if ($esSubproceso) {
            $pdo->prepare("UPDATE productos SET es_subproducto = 1 WHERE id = ?")
                ->execute([$producto_id]);
        }
    } else {
        // El producto NO existía: lo creamos e insertamos ambas banderas
        $stmtNuevo = $pdo->prepare("
          INSERT INTO productos 
            (nombre, densidad_kg_por_l, creado_por, es_para_venta, es_subproducto)
          VALUES (?, NULL, ?, ?, ?)
        ");
        $stmtNuevo->execute([
            $nombre_producto,
            $usuario_id,
            $esParaVenta,
            $esSubproceso
        ]);
        $producto_id = $pdo->lastInsertId();
    }

    // 1.3. Capturar lote mínimo y unidad de lote
    $lote_minimo   = floatval($_POST['lote_minimo']);
    $unidad_lote   = $_POST['unidad']; // 'kg' o 'g'
    $instrucciones = trim($_POST['instrucciones']);

    if ($lote_minimo <= 0) {
        die("Error: El lote mínimo debe ser un número mayor que cero.");
    }

    // 1.4. Insertar registro en fichas_produccion
    $pdo->beginTransaction();
    $stmt1 = $pdo->prepare("
      INSERT INTO fichas_produccion 
        (producto_id, lote_minimo, unidad_produccion, instrucciones, creado_por)
      VALUES (?, ?, ?, ?, ?)
    ");
    $stmt1->execute([
        $producto_id,
        $lote_minimo,
        $unidad_lote,
        $instrucciones,
        $usuario_id
    ]);
    $ficha_id = $pdo->lastInsertId();

    // 1.5. Insertar cada materia prima en gramos dentro de ficha_mp
    foreach ($_POST['mp_id'] as $i => $mp_id) {
        $cantidad_gramos = floatval($_POST['cantidad_gramos'][$i]);
        if ($mp_id && $cantidad_gramos > 0) {
            $stmt2 = $pdo->prepare("
              INSERT INTO ficha_mp (ficha_id, mp_id, porcentaje_o_gramos)
              VALUES (?, ?, ?)
            ");
            $stmt2->execute([$ficha_id, $mp_id, $cantidad_gramos]);
        }
    }

    // 1.6. Si es producto para venta, asignar todas las presentaciones por defecto
    if ($esParaVenta) {
        // Obtener todos los IDs de presentaciones
        $todasPres = $pdo
            ->query("SELECT id FROM presentaciones")
            ->fetchAll(PDO::FETCH_COLUMN, 0);
        $stmtInsPres = $pdo->prepare("
          INSERT INTO productos_presentaciones (producto_id, presentacion_id)
          VALUES (?, ?)
        ");
        foreach ($todasPres as $pid) {
            $stmtInsPres->execute([$producto_id, $pid]);
        }
        // Si prefieres asignar manualmente las presentaciones, comenta este bloque
    }

    $pdo->commit();
    header("Location: fichas_produccion.php?ok=1");
    exit;
}

// 2) Listar todas las materias primas (activo=1)
$mp = $pdo->query("
    SELECT id, nombre, unidad
      FROM materias_primas
     WHERE activo = 1
  ORDER BY nombre
")->fetchAll(PDO::FETCH_ASSOC);

$sub = $pdo->query("
    SELECT
      id + 100000       AS id,      /* para evitar choque con MP */
      nombre,
      'g'               AS unidad   /* o la unidad que use tu subproceso */
    FROM productos
   WHERE es_subproducto = 1
  ORDER BY nombre
")->fetchAll(PDO::FETCH_ASSOC);

$mp = array_merge($mp, $sub);

?>
<?php include 'header.php'; ?>
<div class="container mt-4">
  <h3 class="text-danger mb-3">Crear Ficha de Producción</h3>

  <?php if (isset($_GET['ok'])): ?>
    <div class="alert alert-success">Ficha registrada correctamente.</div>
  <?php endif; ?>

  <form method="POST">
    <!-- ==================== -->
    <!--  PRODUCTO A FABRICAR -->
    <!-- ==================== -->
    <div class="row mb-3">
      <div class="col-md-8">
        <label>Producto a fabricar</label>
        <input 
          type="text" 
          name="nombre_producto" 
          class="form-control" 
          placeholder="Ej. Fondo de Relleno Gris" 
          required
        >
        <small class="text-muted">
          Si no existe en el catálogo, se creará con este nombre.  
          Luego podrás editar densidad y presentaciones en “Productos”.
        </small>
      </div>

      <div class="col-md-2">
        <label>Lote mínimo (en)</label>
        <input 
          name="lote_minimo" 
          type="number" 
          step="0.01" 
          class="form-control" 
          placeholder="Ej. 25" 
          required
        >
      </div>

      <div class="col-md-2">
        <label>Unidad de lote</label>
        <select name="unidad" class="form-select" required>
          <option value="kg">Kilogramos</option>
          <option value="g">Gramos</option>
        </select>
      </div>
    </div>

    <!-- ==================== -->
    <!--  CASILLA “PARA VENTA” -->
    <!-- ==================== -->
    <div class="form-check mb-3">
      <input 
        type="checkbox" 
        class="form-check-input" 
        name="para_venta" 
        id="para_venta"
      >
      <label class="form-check-label" for="para_venta">
        <strong>Este producto es terminado y se venderá directamente</strong>
      </label>
      <small class="form-text text-muted">
        Si marcas esto, el sistema lo agregará automáticamente al catálogo de venta  
        (se le asignarán todas las presentaciones por defecto).  
        Luego podrás ajustar las presentaciones específicas en 
        <a href="productos.php">Productos</a>.
      </small>
    </div>

    <!-- ============================= -->
    <!-- CASILLA “ES SUBPROCESO” (NUEVO) -->
    <!-- ============================= -->
    <div class="form-check mb-3">
      <input 
        type="checkbox" 
        class="form-check-input" 
        name="es_subproducto" 
        id="es_subproducto"
      >
      <label class="form-check-label" for="es_subproducto">
        <strong>Este producto es un subproceso</strong>
        <small class="text-muted">
          (se usará como insumo en otro producto)
        </small>
      </label>
    </div>

    <!-- ==================== -->
    <!--   INSTRUCCIONES (OPC) -->
    <!-- ==================== -->
    <label>Instrucciones (opcional)</label>
    <textarea 
      name="instrucciones" 
      class="form-control mb-4" 
      rows="2"
      placeholder="Ej. Mezclar con agitación lenta por 10 minutos..."
    ></textarea>

    <!-- ==================== -->
    <!--  TABLA DE MATERIAS PRIMAS -->
    <!-- ==================== -->
    <h5>Materias primas (en gramos)</h5>
    <table class="table" id="tablaMP">
      <thead>
        <tr>
          <th style="width: 50%;">Materia Prima</th>
          <th style="width: 20%;">Unidad</th>
          <th style="width: 20%;">Cantidad en gramos</th>
          <th style="width: 10%;"></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <select name="mp_id[]" class="form-select" required>
              <option value="">Selecciona</option>
              <?php foreach ($mp as $m): ?>
                <option value="<?= $m['id'] ?>">
                  <?= htmlspecialchars($m['nombre']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </td>
          <td class="unidad-texto"><?= $mp[0]['unidad'] ?? '' ?></td>
          <td>
            <input 
              type="number" 
              step="0.01" 
              name="cantidad_gramos[]" 
              class="form-control" 
              placeholder="Ej. 7540" 
              required
            >
          </td>
          <td>
            <button 
              type="button" 
              class="btn btn-danger btn-sm" 
              onclick="eliminarFila(this)"
            >✖</button>
          </td>
        </tr>
      </tbody>
    </table>

    <button 
      type="button" 
      class="btn btn-outline-primary btn-sm mb-4" 
      onclick="agregarFila()"
    >+ Añadir fila</button>

    <button class="btn btn-primary">Guardar ficha</button>
  </form>
</div>

<script>
// Duplica la primera fila para añadir otra materia prima
function agregarFila() {
  const row = document.querySelector("#tablaMP tbody tr");
  const nueva = row.cloneNode(true);
  // Limpiar inputs de la nueva fila
  nueva.querySelectorAll("input").forEach(input => input.value = "");
  row.parentNode.appendChild(nueva);
}
// Elimina la fila correspondiente, si queda al menos 1
function eliminarFila(btn) {
  const filas = document.querySelectorAll("#tablaMP tbody tr");
  if (filas.length > 1) {
    btn.closest("tr").remove();
  }
}
</script>
<?php include 'footer.php'; ?>
