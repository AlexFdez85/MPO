
<?php
// inventario_mp.php

// -------------------------------------
// 1) Mostrar errores (solo desarrollo)
// -------------------------------------
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';

// -------------------------------------
// 2) Validar sesión y rol base
// -------------------------------------
if (!isset($_SESSION['user_id'])
    || !in_array($_SESSION['rol'], ['produccion','logistica','gerente','admin'])
) {
    header('Location: login.php');
    exit;
}

$usuario_id  = $_SESSION['user_id'];
$rol         = $_SESSION['rol'];
$nombre      = $_SESSION['nombre'];
// Sólo admin y gerente pueden registrar movimientos directos
$canRegistro = in_array($rol, ['admin','gerente']);

// -------------------------------------
// 3) Procesar “Registrar Movimiento”
// -------------------------------------
if ($canRegistro
    && $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['registrar_movimiento'])
) {
    // separar tipo y id: valor viene como MP-<id> o SP-<id>
    if (!preg_match('/^(MP|SP)-(\d+)$/', $_POST['item_id'], $m)) {
        $error = "Ítem inválido.";
    } else {
        $tipoItem  = $m[1];  // 'MP' o 'SP'
        $item_id   = intval($m[2]);
        $movType   = $_POST['tipo'];       // 'entrada' o 'salida'
        $cantidad  = floatval($_POST['cantidad']);
        $comentario= trim($_POST['comentario']);
        $fecha_mov = date('Y-m-d H:i:s');

        if ($tipoItem === 'MP') {
            // materia prima
            $stmt = $pdo->prepare("SELECT existencia FROM materias_primas WHERE id = ?");
            $stmt->execute([$item_id]);
            $stockActual = (float) $stmt->fetchColumn();
            if ($movType === 'salida' && $cantidad > $stockActual) {
                $error = "No hay suficiente stock de materia prima para esta salida.";
            } else {
                $pdo->beginTransaction();
                $pdo->prepare(
                    "INSERT INTO movimientos_mp (mp_id, tipo, cantidad, fecha, usuario_id, comentario)
                     VALUES (?, ?, ?, ?, ?, ?)"
                )->execute([$item_id, $movType, $cantidad, $fecha_mov, $usuario_id, $comentario]);
                $nuevo = $movType === 'entrada'
                       ? $stockActual + $cantidad
                       : $stockActual - $cantidad;
                $pdo->prepare("UPDATE materias_primas SET existencia = ? WHERE id = ?")
                    ->execute([$nuevo, $item_id]);
                $pdo->commit();
                header("Location: inventario_mp.php?ok_mov=1");
                exit;
            }
        } else {
            // subproceso → se registra como producción en gramos
            $pres = $pdo->prepare("SELECT id FROM presentaciones WHERE nombre = ?");
            $pres->execute(['Gramos']);
            $idGramos = $pres->fetchColumn();
            if (!$idGramos) {
                $error = "Falta la presentación 'Gramos' en la base de datos.";
            } else {
                $pdo->prepare(
                  "INSERT INTO productos_terminados
                   (orden_id, producto_id, presentacion_id, cantidad, lote_produccion, fecha)
                   VALUES (NULL, ?, ?, ?, NULL, ?)"
                )->execute([$item_id, $idGramos, $cantidad, date('Y-m-d')]);
                header("Location: inventario_mp.php?ok_mov=1");
                exit;
            }
        }
    }
}

// -------------------------------------
// 4) Proponer Ajuste de Inventario
// -------------------------------------
if ($rol !== 'admin'
    && $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['proponer_ajuste'])
) {
    $aj_id       = intval($_POST['item_id']);
    $aj_cantidad = floatval($_POST['cantidad_aj']);
    $aj_coment   = trim($_POST['comentario_aj']);
    if ($aj_id <= 0 || $aj_cantidad == 0 || $aj_coment === '') {
        $error = "Todos los campos del ajuste son obligatorios.";
    } else {
        $pdo->prepare(
          "INSERT INTO ajustes_mp (mp_id, cantidad, comentario, solicitante_id, fecha_solicitud, estado)
           VALUES (?, ?, ?, ?, NOW(), 'pendiente')"
        )->execute([$aj_id, $aj_cantidad, $aj_coment, $usuario_id]);
        header("Location: inventario_mp.php?ok_ajuste=1");
        exit;
    }
}

// -------------------------------------
// 5) Ajustes pendientes (solo admin)
// -------------------------------------
$ajustesPendientes = [];
if ($rol === 'admin') {
    $ajustesPendientes = $pdo->query(
      "SELECT a.id, mp.nombre AS mp_nombre, a.cantidad, a.comentario, u.nombre AS solicitante
       FROM ajustes_mp a
       JOIN materias_primas mp ON a.mp_id = mp.id
       JOIN usuarios u ON a.solicitante_id = u.id
       WHERE a.estado = 'pendiente'"
    )->fetchAll(PDO::FETCH_ASSOC);
}

// -------------------------------------
// 6) Cargar MP y Subprocesos
// -------------------------------------
// 6.a Materias primas
$mpRows = $pdo->query(
  "SELECT id, nombre, unidad, existencia FROM materias_primas ORDER BY nombre"
)->fetchAll(PDO::FETCH_ASSOC);
// 6.b Subprocesos (stock en gramos)
$presGrStmt = $pdo->prepare("SELECT id FROM presentaciones WHERE nombre = ?");
$presGrStmt->execute(['Gramos']);
$idPresGr = $presGrStmt->fetchColumn() ?: 0;
$subStmt = $pdo->prepare(
  "SELECT p.id AS id, p.nombre AS nombre, fp.unidad_produccion AS unidad,
          COALESCE(SUM(pt.cantidad),0) AS existencia
     FROM fichas_produccion fp
     JOIN productos p ON fp.producto_id = p.id
     LEFT JOIN productos_terminados pt
       ON pt.producto_id = p.id AND pt.presentacion_id = ?
    WHERE p.es_subproducto = 1
    GROUP BY p.id, p.nombre, fp.unidad_produccion"
);
$subStmt->execute([$idPresGr]);
$subRows = $subStmt->fetchAll(PDO::FETCH_ASSOC);
// unir y ordenar
$items = array_merge(
    array_map(fn($r)=>array_merge($r,['tipo'=>'MP']), $mpRows),
    array_map(fn($r)=>array_merge($r,['tipo'=>'Subproceso']), $subRows)
);
usort($items, fn($a,$b)=>strcasecmp($a['nombre'],$b['nombre']));
include 'header.php';
?>
<div class="container mt-4">
  <h3 class="text-danger mb-3">Inventario de MP & Subprocesos</h3>

  <!-- Mensajes -->
  <?php if (isset($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php elseif (isset($_GET['ok_mov'])): ?>
    <div class="alert alert-success">Movimiento registrado correctamente.</div>
  <?php elseif (isset($_GET['ok_ajuste'])): ?>
    <div class="alert alert-success">Ajuste propuesto correctamente.</div>
  <?php endif; ?>

  <!-- Formulario Registrar Movimiento -->
  <?php if ($canRegistro): ?>
  <div class="card mb-4 p-3">
    <h5>Registrar Movimiento</h5>
    <form method="POST">
      <div class="row g-3 align-items-end">
        <div class="col-md-4">
          <label>Ítem</label>
          <select name="item_id" class="form-select" required>
            <optgroup label="Materias Primas">
              <?php foreach($items as $it): if($it['tipo']!=='MP') continue; ?>
                <?php $ex=($it['unidad']==='kg'? $it['existencia']*1000: $it['existencia']); ?>
                <option value="MP-<?= $it['id'] ?>">
                  <?= htmlspecialchars($it['nombre']) ?> (<?= number_format($ex,2) ?> g)
                </option>
              <?php endforeach; ?>
            </optgroup>
            <optgroup label="Subprocesos">
              <?php foreach($items as $it): if($it['tipo']!=='Subproceso') continue; ?>
                <?php $ex=($it['unidad']==='kg'? $it['existencia']*1000: $it['existencia']); ?>
                <option value="SP-<?= $it['id'] ?>">
                  <?= htmlspecialchars($it['nombre']) ?> (<?= number_format($ex,2) ?> g)
                </option>
              <?php endforeach; ?>
            </optgroup>
          </select>
        </div>
        <div class="col-md-2">
          <label>Movimiento</label>
          <select name="tipo" class="form-select" required>
            <option value="entrada">Entrada</option>
            <option value="salida">Salida</option>
          </select>
        </div>
        <div class="col-md-2">
          <label>Cantidad (g)</label>
          <input type="number" name="cantidad" step="0.01" class="form-control" value="0" required>
        </div>
        <div class="col-md-3">
          <label>Comentario</label>
          <input type="text" name="comentario" class="form-control">
        </div>
        <div class="col-md-1 text-end">
          <button type="submit" name="registrar_movimiento" class="btn btn-primary">Registrar</button>
        </div>
      </div>
    </form>
  </div>
  <?php endif; ?>

  <!-- Formulario Proponer Ajuste -->
  <?php if ($rol!=='admin'): ?>
  <div class="card mb-4 p-3">
    <h5>Proponer Ajuste de Inventario</h5>
    <form method="POST">
      <div class="row g-3 align-items-end">
        <div class="col-md-4">
          <label>Ítem</label>
          <select name="item_id" class="form-select" required>
            <?php foreach($items as $it): ?>
            <option value="<?= $it['id'] ?>"><?= htmlspecialchars($it['nombre']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3">
          <label>Cantidad (g)</label>
          <input type="number" name="cantidad_aj" step="0.01" class="form-control" required>
        </div>
        <div class="col-md-4">
          <label>Comentario (obligatorio)</label>
          <input type="text" name="comentario_aj" class="form-control" required>
        </div>
        <div class="col-md-1 text-end">
          <button type="submit" name="proponer_ajuste" class="btn btn-warning">Enviar</button>
        </div>
      </div>
    </form>
  </div>
  <?php endif; ?>

  <!-- Ajustes Pendientes (admin) -->
  <?php if ($rol==='admin'): ?>
  <div class="card mb-4 p-3">
    <h5>Ajustes Pendientes de Autorización</h5>
    <?php if(empty($ajustesPendientes)): ?>
      <div class="alert alert-secondary">No hay ajustes pendientes.</div>
    <?php else: ?>
      <table class="table table-striped">
        <thead><tr><th>#</th><th>MP</th><th>Cant. (g)</th><th>Solicita</th><th>Comentario</th></tr></thead>
        <tbody>
        <?php foreach($ajustesPendientes as $aj): ?>
        <tr>
          <td><?= $aj['id'] ?></td>
          <td><?= htmlspecialchars($aj['mp_nombre']) ?></td>
          <td><?= number_format($aj['cantidad'],2) ?></td>
          <td><?= htmlspecialchars($aj['solicitante']) ?></td>
          <td><?= htmlspecialchars($aj['comentario']) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- Inventario Completo -->
  <div class="card mb-5 p-3">
    <h5>Lista de Materias Primas y Subprocesos</h5>
    <table class="table table-striped">
      <thead><tr><th>Nombre</th><th>Unidad</th><th>Existencia (g)</th><th>Tipo</th></tr></thead>
      <tbody>
      <?php foreach($items as $m):
        $u = $m['unidad']?:'g';
        $ex=($u==='kg'? $m['existencia']*1000: $m['existencia']);
      ?>
        <tr>
          <td><?= htmlspecialchars($m['nombre']) ?></td>
          <td><?= htmlspecialchars($u) ?></td>
          <td><?= number_format($ex,2) ?></td>
          <td><?= $m['tipo']==='MP'? 'MP':'Subproceso' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include 'footer.php'; ?>
```




